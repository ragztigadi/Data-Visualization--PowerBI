Sneak Peek of SuperStore Sales Visualization

Sales Analysis:
![Alt text](/SuperStore_Sales/SuperStoreSales_Dashboard.png?raw=true "SuperStore Sales Dashboard2")


Sales Forecasting for next 15 days Through Power BI
![Alt text](/SuperStore_Sales/SuperStoreSales_Forecasting.png?raw=true "SuperStore Sales Forecasting Dashboard")

