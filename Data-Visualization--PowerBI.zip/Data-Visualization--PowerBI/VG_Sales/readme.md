Welcome to My PowerBI project!<br>
Here is a preview of the Dashboard for the Video game sales dataset

![Alt text](/VG_Sales/VGSales_ss.png?raw=true "Vedio Games Sales Dashboard")
