Sneak peek of the visualisation for HR_Analytics through Power BI

Attrition Analysis:
![Alt text](/HR_Analytics/HR_Analytics_PowerBI_SS2.png?raw=true "HR_Analytics Dashboard2")



![Alt text](/HR_Analytics/HR_Analytics_PowerBI_SS.png?raw=true "HR Analytics Dashboard")

